
# Clipper Agent (Render + Replit + GitHub)

Single codebase that deploys on **Render** (production) and runs on **Replit** (dev).

- MoviePy is **enabled** on Render (env `USE_MOVIEPY=1`).
- If MoviePy import fails anywhere, it **falls back** to raw `ffmpeg`.
- Endpoint: `POST /clip` (form field `file` with an MP4). Returns `clipped.mp4` with a watermark overlay.

## Local/Dev
```bash
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```

## Render
1. Push this folder to GitHub.
2. Create a new **Web Service** on Render → Import from GitHub.
3. Render reads `render.yaml` and deploys automatically.

## Replit
- Open this folder in Replit; it will use `.replit` to run the server on port 8000.
- The included `replit.nix` ensures `ffmpeg` exists.

## API
- `GET /health` → `{"ok": true, "moviepy": true|false}`
- `POST /clip` → Multipart form `file=@yourvideo.mp4`, returns processed MP4.

## Watermark
Replace `watermark.png` (top-left overlay). Use a transparent PNG.
